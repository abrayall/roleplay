=== Roleplay ===
Contributors: abrayall
Tags: wordpress
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 0.1.0
Requires PHP: 7.4
License: GPL-2.0+
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Wordpress User Role Editor

== Installation ==

1. Upload the plugin files to the /wp-content/plugins/ directory
2. Activate the plugin through the 'Plugins' screen in WordPress
